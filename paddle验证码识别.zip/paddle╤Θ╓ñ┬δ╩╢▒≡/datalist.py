import os
import json


#图片数量统计,定义总的名称
all_class_images = 0
all_class_name = 'partition'

#获取总的类别数
all_class_sum = len(os.listdir('/home/aistudio/data/perfect/partition'))

#用于存储每个类别的信息
class_data = []

#给每类图片分配一个对应的标号，便于构建reader()
class_number = 0

#构建所有类别的列表
class_labels = os.listdir('/home/aistudio/data/perfect/partition')

#按类读取进行处理统计
for class_label in class_labels:
    #某个类的路径
    image_dir_path = '/home/aistudio/data/perfect/partition/' + str(class_label)
    image_path_names = os.listdir(image_dir_path)  #该类下的图片列表
    #用于训练集和测试集创建
    class_sum = 0
    test_sum = 0
    trainer_sum = 0
    class_data_list = {}

    
    #将每张图片写入训练集或者测试集
    for image_path_name in image_path_names:
        img_path = image_dir_path + '/' + str(image_path_name)
        if class_sum % 10 == 0:
            test_sum += 1
            with open('/home/aistudio/data/perfect/partition/' + 'test.list','a') as f:
                f.write(img_path + '\t%s' % class_number + '\n')
        else:
            trainer_sum += 1
            with open('/home/aistudio/data/perfect/partition/' + 'trainer.list','a') as f:
                f.write(img_path + '\t%s' % class_number + '\n')
        class_sum += 1
        all_class_images += 1
    class_data_list['class_name'] = class_label
    class_data_list['class_number'] = class_number
    class_data_list['class_test_images'] = test_sum
    class_data_list['class_trainer_images'] = trainer_sum
    #构建数据列表
    class_data.append(class_data_list)
    class_number += 1

#创建json文件为将来预测做准备
seekjson = {}
seekjson['all_class_name'] = 'partition'
seekjson['all_class_sum'] = all_class_sum
seekjson['all_class_images'] = all_class_images
seekjson['class_data'] = class_data
jsons = json.dumps(seekjson, sort_keys=True, indent=4, separators=(',', ': '))
with open('/home/aistudio/data/perfect/partition/' + "readme.json",'w') as f:
    f.write(jsons)

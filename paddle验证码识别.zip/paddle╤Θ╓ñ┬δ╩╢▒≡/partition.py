from PIL import Image
import matplotlib.pyplot as plt
import os
import uuid

#创建partition文件夹
os.makedirs('/home/aistudio/data/perfect/partition')

#分割后图片的根目录
img_rootpath = '/home/aistudio/data/perfect/partition'

#分割前图片的列表
imgs = os.listdir('/home/aistudio/data/perfect/Lucky')


#用4个指定位置box对图片进行分割
box1 = (5, 0, 17, 27)
box2 = (17, 0, 29, 27)
box3 = (29, 0, 41, 27)
box4 = (41, 0, 53, 27) 


#拿出每一张图片进行分割
for img in imgs:
    img_path = '/home/aistudio/data/perfect/Lucky' + '/' + img #分割前图片路径
    pic = Image.open(img_path)  #返回一个image对象
    name = img.split('.')[0]    #去掉后缀,返回每个图片的名字

    #每张图片都将得到四个路径,用于分类存储切割后的图片,
    #并以寻出的相应字母的文件夹下
    path1 = img_rootpath + '/' + name[0]
    path2 = img_rootpath + '/' + name[1]
    path3 = img_rootpath + '/' + name[2]
    path4 = img_rootpath + '/' + name[3]


    #若路径不存在,创建该路径
    if not os.path.exists(path1):
        os.makedirs(path1)
    if not os.path.exists(path2):
        os.makedirs(path2)
    if not os.path.exists(path3):
        os.makedirs(path3)
    if not os.path.exists(path4):
        os.makedirs(path4)


    #进行图片分割,重新设定大小,设定ANTIALIAS可以抗锯齿,得到不错质量的图片
    #将图片存放到对应字母的文件夹下
    pic.crop(box1).resize((36, 36), Image.ANTIALIAS).save(path1 + '/%s.png' % uuid.uuid1())
    pic.crop(box2).resize((36, 36), Image.ANTIALIAS).save(path2 + '/%s.png' % uuid.uuid1())
    pic.crop(box3).resize((36, 36), Image.ANTIALIAS).save(path3 + '/%s.png' % uuid.uuid1())
    pic.crop(box4).resize((36, 36), Image.ANTIALIAS).save(path4 + '/%s.png' % uuid.uuid1())

import paddle.v2 as paddle

#构建reader，data_set--要获取的数据集，reader--用于获取训练或测试数据集及其标签的生成器
def read_data(data_set):
    
    def reader():
        #提取数据集的信息，将路径赋给img_path，标签赋给lab
        with open(data_set, 'r') as f:
            lines = [line.strip() for line in f]
            for line in lines:
                img_path, lab = line.split('\t')
                #从img_path加载灰度图
                img = paddle.image.load_image(img_path, is_color=False)
                #对图片进行简单的调整
                img = paddle.image.simple_transform(img, 38, 32, True, is_color=False)
                #将图片数字转为一维的并转化为float类型的，将lab转化为整形
                yield img.flatten().astype('float32'), int(lab)
    return reader

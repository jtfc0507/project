import json

import numpy as np
import paddle.v2 as paddle
from PIL import Image
#利用vgg得到分类器
out = vgg_bn_drop(datadim=1024, type_size=33)
#通过训练的参数模型得到参数
with open('/home/aistudio/data/model.tar', 'r') as f:
    parameters = paddle.parameters.Parameters.from_tar(f)

#预测图片的路径
path = '/home/aistudio/data/data1405/Lucky/ik7l.png'
#用于存储预测图片分割后的数组
test_data = []
img = Image.open(path)
# 切割图片并保存
box1 = (5, 0, 17, 27)
box2 = (17, 0, 29, 27)
box3 = (29, 0, 41, 27)
box4 = (41, 0, 53, 27)
temp = '/home/aistudio/data/'
img.crop(box1).resize((32, 32), Image.ANTIALIAS).save(temp + '/1.png')
img.crop(box2).resize((32, 32), Image.ANTIALIAS).save(temp + '/2.png')
img.crop(box3).resize((32, 32), Image.ANTIALIAS).save(temp + '/3.png')
img.crop(box4).resize((32, 32), Image.ANTIALIAS).save(temp + '/4.png')
# 把图像加载到预测数据中
test_data.append((paddle.image.load_and_transform(temp + '/1.png', 38, 32, False, is_color=False)
                      .flatten().astype('float32'),))
test_data.append((paddle.image.load_and_transform(temp + '/2.png', 38, 32, False, is_color=False)
                      .flatten().astype('float32'),))
test_data.append((paddle.image.load_and_transform(temp + '/3.png', 38, 32, False, is_color=False)
                      .flatten().astype('float32'),))
test_data.append((paddle.image.load_and_transform(temp + '/4.png', 38, 32, False, is_color=False)
                      .flatten().astype('float32'),))
#打开先前生成的json文件，为我们查表生成预测结果做准备
with open('/home/aistudio/data/perfect/partition/readme.json' ) as f:
    txt = f.read()
    readjson = json.loads(txt)
# 获得预测结果，probs是个二维概率数组
probs = paddle.infer(output_layer=out,
                        parameters=parameters,
                        input=test_data)

# 处理预测结果,将概率从大到小排序，返回对应index
lab = np.argsort(-probs)

# 返回概率最大的值和其对应的概率值
result = ''
for i in range(0, lab.__len__()):
    print '第%d张预测结果为:%d,可信度为:%f' % (i + 1, lab[i][0], probs[i][(lab[i][0])])
    class_datas = readjson['class_data']
    for class_data in class_datas:
        if class_data['class_label'] == lab[i][0]:
            label =  class_data['class_name']
    result = result + str(label)
print '预测结果为:%s' % result

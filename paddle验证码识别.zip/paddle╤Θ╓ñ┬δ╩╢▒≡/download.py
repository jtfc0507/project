import urllib.request
import uuid
import os


#正方系统验证码的url
url = 'http://jwsys.ctbu.edu.cn/CheckCode.aspx?'


#要爬取1000张验证码，sum作为计数
sum = 0


#创建爬取下来的验证码的存放路径
os.makedirs(r'D:\Lucky')
save_path = r'D:\Lucky'


#用while循环进行次数的控制
while sum < 1000:
    try:
        #通过urllib.request.urlopen()函数访问网页,通过read()读取内容
        image = urllib.request.urlopen(url)
        img = image.read()

        #存储为.png格式的图片(uuid可以方便我们取名),每次存储完成后,sum计数加一
        img_name = save_path+'/'+str(uuid.uuid1())+'.png'
        with open(img_name,'wb') as f:
            f.write(img)
            sum += 1
        print ('已下载'+str(sum)+'张验证码')
    except:
        print ('当前图片无法下载，%s'%sum)

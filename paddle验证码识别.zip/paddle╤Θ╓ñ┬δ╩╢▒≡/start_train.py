import sys
import os
import paddle.v2 as paddle

#训练集的reader
trainer_reader = read_data("/home/aistudio/data/perfect/partition/trainer.list" )
#测试集的reader
test_reader = read_data("/home/aistudio/data/perfect/partition/test.list" )
# 对数据进行打乱并读取，有利于模型的训练
reader = paddle.batch(reader=paddle.reader.shuffle(reader=trainer_reader,
                                                    buf_size=50000),
                                                    batch_size=128)
# 指定每条数据和padd.layer.data的对应关系
feeding = {"image": 0, "label": 1}
def event_handler(event):
    #每100batch就打印pass_id,batch_id,cost以及metrics，否则打印....
    if isinstance(event, paddle.event.EndIteration):
        if event.batch_id % 100 == 0:
            print "\nPass %d, Batch %d, Cost %f, %s" % (
                event.pass_id, event.batch_id, event.cost, event.metrics)
        else:
            sys.stdout.write('.')
            sys.stdout.flush()

    # 每一轮训练完成之后，保存训练好的参数，#测试准确率
    if isinstance(event, paddle.event.EndPass):
                
        with open('/home/aistudio/data/model.tar', 'w') as f:
            trainer.save_parameter_to_tar(f)
            
        result = trainer.test(reader=paddle.batch(reader=test_reader,
                                                    batch_size=128),
                                                    feeding=feeding)
        print "\nTest with Pass %d, %s" % (event.pass_id, result.metrics)
    #reader 训练数据
    #num_passes 训练的轮数
    #event_handler 训练的事件
    #feeding 说明每条数据和padd.layer.data的对应关系
trainer.train(reader=reader,
                num_passes=500,
                event_handler=event_handler,
                feeding=feeding)

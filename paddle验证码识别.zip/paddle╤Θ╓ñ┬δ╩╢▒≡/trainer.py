import paddle.v2 as paddle

#创建训练器
# 获得图片对于的信息标签,一共有33种标签
label = paddle.layer.data(name="label",
                            type=paddle.data_type.integer_value(33))
# 利用vgg得到分类器
out = vgg_bn_drop(datadim=1024, type_size=33)
# 获得损失函数
cost = paddle.layer.classification_cost(input=out, label=label)
#获得参数
parameters = paddle.parameters.create(cost)
#定义优化方法
optimizer = paddle.optimizer.Momentum(
            momentum=0.9,
            regularization=paddle.optimizer.L2Regularization(rate=0.0005 * 128),
            learning_rate=0.0001 / 128,
            learning_rate_decay_a=0.1,
            learning_rate_decay_b=128000 * 35,
            learning_rate_schedule="discexp", )

trainer = paddle.trainer.SGD(cost=cost,
                                     parameters=parameters,
                                     update_equation=optimizer)
